// src/components/AttendanceChart.tsx
import { useMemo } from "react"
import { View, Text, StyleSheet, Dimensions } from "react-native"
import {
  CartesianChart,
  Line,
  CartesianAxis,
  useLinePath
} from "victory-native"
import { colors, spacing, type as typo } from "../theme"

type TrendPoint = { date: string; percentage: number }

type AttendanceChartProps = {
  data: TrendPoint[]
  subject: string
  threshold?: number
  height?: number
}

export default function AttendanceChart({ data, subject, threshold = 75, height = 200 }: AttendanceChartProps) {
  const { width } = Dimensions.get("window")
  const chartWidth = width - spacing(8)

  const chartData = useMemo(() => {
    return data.map((d, i) => ({
      x: i,
      y: d.percentage,
      label: d.date
    }))
  }, [data])

  const domain = useMemo(() => {
    const minY = Math.max(0, Math.min(...data.map(d => d.percentage)) - 10)
    const maxY = Math.min(100, Math.max(...data.map(d => d.percentage)) + 10)
    return { x: [0, Math.max(1, data.length - 1)], y: [minY, maxY] }
  }, [data])

  const thresholdLine = useMemo(() => {
    return [
      { x: 0, y: threshold },
      { x: Math.max(1, data.length - 1), y: threshold }
    ]
  }, [data.length, threshold])

  const thresholdPath = useLinePath({
    data: thresholdLine,
    x: "x",
    y: "y",
    scale: { x: { domain: domain.x }, y: { domain: domain.y } },
    interpolation: "natural"
  })

  const mainPath = useLinePath({
    data: chartData,
    x: "x",
    y: "y",
    scale: { x: { domain: domain.x }, y: { domain: domain.y } },
    interpolation: "natural"
  })

  if (data.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No attendance data for {subject} this semester</Text>
      </View>
    )
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{subject} Attendance Trend</Text>
      <View style={{ width: chartWidth, height }}>
        <CartesianChart
          domain={domain}
          width={chartWidth}
          height={height}
          padding={{ top: 20, right: 20, bottom: 40, left: 50 }}
        >
          <CartesianAxis
            dependentAxis
            style={{
              axis: { stroke: colors.outline },
              tickLabels: { ...typo.body, fontSize: 10, fill: colors.onSurfaceVariant },
              grid: { stroke: colors.outline, strokeDasharray: "4,4" }
            }}
            tickFormat={tick => `${tick}%`}
          />
          <CartesianAxis
            independentAxis
            tickValues={data.length > 10 ? data.map((_, i) => i).filter((_, i) => i % Math.ceil(data.length / 5) === 0) : data.map((_, i) => i)}
            tickFormat={(tick, _, points) => points[tick]?.label ? points[tick].label.slice(5) : ""}
            style={{
              axis: { stroke: colors.outline },
              tickLabels: { ...typo.body, fontSize: 10, fill: colors.onSurfaceVariant, angle: -45 }
            }}
          />
          <Line
            data={thresholdLine}
            x="x"
            y="y"
            style={{
              stroke: colors.error,
              strokeWidth: 1,
              strokeDasharray: "5,5"
            }}
            interpolation="natural"
          />
          <Line
            data={chartData}
            x="x"
            y="y"
            style={{
              stroke: colors.primary,
              strokeWidth: 2
            }}
            interpolation="natural"
          />
        </CartesianChart>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: spacing(4),
    marginBottom: spacing(3),
    alignItems: "center"
  },
  title: {
    ...typo.title,
    fontSize: 14,
    marginBottom: spacing(2),
    color: colors.onSurface
  },
  emptyContainer: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: spacing(6),
    alignItems: "center"
  },
  emptyText: {
    ...typo.body,
    color: colors.onSurfaceVariant,
    textAlign: "center"
  }
})